<!DOCTYPE html>
<!-- Created By CodingLab - www.codinglabweb.com -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title> Elector Shop | Regristration</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script type="text/javascript" src="js/cufon-yui.js"></script>
    <script type="text/javascript" src="js/arial.js"></script>
    <script type="text/javascript" src="js/cuf_run.js"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <script>
</script>
   </head>
<body>
  <div class="container">
    <div class="title">Registration</div>
    <?php
    error_reporting(1);
    include("connection.php");
    $username=$_POST['t1'];
    $phone=$_POST['t2'];
    $email=$_POST['t3'];
    $address=$_POST['t4'];
    $password=$_POST['t5'];
    $confirmpassword=$_POST['t6'];
    if(isset($_POST["sub"])){
      $qry="insert into register(username,phone,email,address,password,confirmpassword)values('$username','$phone','$email','$address','$password','$confirmpassword')";
      $result = mysqli_query($con, $qry) or die("Save items query failed.");
    if($result)
    {
      header("location:reg_success.php? username=$username & email=$email");
    }
      else {$error= "user already exists";}
    }
    ?>
    <div class="content">
      <form  method="post" action="#">
        <div class="user-details">
          <div class="input-box">
            <span class="details">UserName</span>
            <input type="text" id="t1" name="t1"  placeholder="Enter your username" required>
          </div>
          <div class="input-box">
            <span class="details">PhoneNumber</span>
            <input type="text"  id="t2" name="t2"  placeholder="Enter your number" required>
          </div>
          <div class="input-box">
            <span class="details">Email</span>
            <input type="text" id="t3" name="t3"  placeholder="Enter your email" required>
          </div>
          <div class="input-box">
            <span class="details">Address</span>
            <input type="text" id="t4" name="t4" placeholder="Enter your address" required>
          </div>
          <div class="input-box">
            <span class="details">Password</span>
            <input type="text" id="t5" name="t5"  placeholder="Enter your password" required>
          </div>
          <div class="input-box">
            <span class="details">Confirm Password</span>
            <input type="text" id="t6" name="t6"  placeholder="Confirm your password" required>
          </div>
        </div>
        <div class="button">
          <input type="submit" name="sub" id="sub" value="Register">
        </div>
      </form>
    </div>
  </div>
</body>
</html>