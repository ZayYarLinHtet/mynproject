-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 25, 2023 at 11:14 AM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `eledb`
--

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE IF NOT EXISTS `brand` (
  `b_id` int(100) NOT NULL AUTO_INCREMENT,
  `b_title` varchar(50) NOT NULL,
  PRIMARY KEY (`b_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`b_id`, `b_title`) VALUES
(1, 'MI'),
(2, 'SAMSUNG'),
(3, 'DELL'),
(4, 'ASUS'),
(5, 'acer'),
(6, 'VJUN'),
(7, 'Remax'),
(8, 'Barmaso');

-- --------------------------------------------------------

--
-- Table structure for table `buy`
--

CREATE TABLE IF NOT EXISTS `buy` (
  `brand` varchar(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `price` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `delivery` varchar(20) NOT NULL,
  `address` varchar(200) NOT NULL,
  `Order_no` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buy`
--

INSERT INTO `buy` (`brand`, `name`, `price`, `phone`, `delivery`, `address`, `Order_no`) VALUES
('mi', 'Dummy 5', '90000ks', '123456', '3 days', 'jkiijn', '18'),
('mi', 'Zay Yar Lin Htet', 'gasg', '09876543123', 'next day', 'Yangon', '45'),
('', 'Dummy 5', '90000ks', '098181038', '5 days', 'Yangon', '92'),
('ASUS', 'ASUS Vivobook 16_X1605VA-MB255', '2,787,000', '09876543123', '5 days', 'Yangon', 'no16'),
('ASUS', 'ASUS TUF Gaming F15 (I7-12th G', '3,524,000 ', '123456', '3 days', 'yg', 'no16'),
('Remax', 'RB - X5 Outdoor Bluetooth Spea', '405,000 ', '567890', 'next day', 'man', 'no8'),
('Remax', 'Remax RM-712 Gaming Wired Earp', '33,500', '123456', '3 days', 'yu', 'no37'),
('ASUS', 'Asus VivoBook 15 X515MA-EJ787W', '999,000', '09876543123', '3 days', 'Yangon', 'no13'),
('Remax', 'Remax Earphone (RM-501)', '10,875', '098978999', 'next day', 'Yangon', 'no65'),
('MI', 'Mi Bro A1', '75,000', '098765567', 'next day', 'Yangon', 'no58');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_name` varchar(50) NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`c_id`, `c_name`) VALUES
(1, 'Laptop'),
(2, 'Smart phone'),
(3, 'Smart Watch'),
(4, 'Ear Buds'),
(5, 'Bluetooth Speaker'),
(6, 'Accessories'),
(7, 'Covers');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `con_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` text NOT NULL,
  `feedback` varchar(255) NOT NULL,
  PRIMARY KEY (`con_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`con_id`, `name`, `email`, `subject`, `feedback`) VALUES
(1, 'Zay Yar Lin Htet', 'zylhucsmb@gmail.com', 'good', 'hi'),
(2, 'Zay Yar Lin Htet', 'zylhucsmb@gmail.com', 'good', 'hi'),
(3, 'Zay Yar Lin Htet', 'zylhucsmb@gmail.com', 'good', 'hi'),
(4, 'Zay Yar Lin Htet', 'zylhucsmb@gmail.com', 'good', '    hi my name is zay yar lin htet'),
(5, 'Kyaw Kyaw', 'Ky@gamil.com', 'good', 'good'),
(6, 'Zai', 'Zai@gmail.com', 'very good at web site', 'hi'),
(7, 'cg', 'cg@gmail.com', 'giii', 'xxxx'),
(8, 'cg', 'cg@gmail.com', 'giii', 'xxxx'),
(9, 'cg', 'cg@gmail.com', 'giii', 'xxxx'),
(10, 'Kay', 'Ky@gamil.com', 'dummy', 'dummy1'),
(11, 'Kyal Kyal', 'Ky@gamil.com', 'very good at web site', 'improve'),
(12, 'Dummy3', 'dum3@gmail.com', 'Suggestion', 'need improve');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `p_id` int(100) NOT NULL AUTO_INCREMENT,
  `p_name` text NOT NULL,
  `p_brand` varchar(50) NOT NULL,
  `p_category` text NOT NULL,
  `p_price` varchar(100) NOT NULL,
  `p_img` varchar(255) NOT NULL,
  `p_desc` varchar(255) NOT NULL,
  `p_spec` varchar(100) NOT NULL,
  `p_color` text NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`p_id`, `p_name`, `p_brand`, `p_category`, `p_price`, `p_img`, `p_desc`, `p_spec`, `p_color`) VALUES
(1, 'Xiaomi Redmi Note 11 4G (6/128GB)', 'MI', 'Smart phone', '509,000', 'Xiaomi-Redmi-Note-11.jpg', 'ð—ªð—˜ð—Ÿð—–ð—¢ð— ð—˜ ð—™ð—¿ð—¼ð—º UOK\r\nð—§ð—µð—¶ð˜€ ð—£ð—¿ð—¼ð—±ð˜‚ð—°ð˜ ð—¶ð˜€ ð—¢ð—³ð—³ð—¶ð—°ð—¶ð—®ð—¹ ðŸ­ ð—¬ð—²ð—®ð—¿ ð—ªð—®ð—¿ð—¿ð—®ð—»ð˜ð˜†\r\nðŸ­ðŸ¬ðŸ¬% ð—•ð—¿ð—®ð—»ð—± ð—¡ð—²ð˜„ ð—£ð—®ð—°', 'BrandXiaomiSKU110214185_MM-1036915648Body TypePlasticNumber Of Cameras4Pre-OwnedNoNotchted DisplayNo', 'Carbon Gray/Pebble White/Sea Blue'),
(4, 'Xiaomi 13 Ultra 5G 12/512GB ', 'MI', 'Smart phone', '4,331,000 ', '0.3xiaomi-13-ultra.jpg0.3xiaomi-13-ultra.jpg', '2 Years Xiaomi Singapore Warranty\r\n6.73 inches, LTPO AMOLED, 1B colors, 120Hz, Dolby Vision, HDR10+, 1300 nits (HBM), 2600 nits (peak)\r\nCorning Gorilla Glass Victus\r\nIP68 dust/water resistant\r\nQualcomm SM8550-AB Snapdragon 8 Gen 2\r\nAndroid 13, MIUI 14\r\nDo', 'BrandXiaomiSKU117237097_MM-1037376563Body TypeGlassNumber Of Cameras4Pre-OwnedNot SpecifiedNotchted ', 'Black/Olive Green/White/Orange/Yellow/Blue'),
(5, 'Xiaomi Pad 6 (6/128GB)', 'MI', 'Smart phone', '799,000', 'Xiaomi Pad6.jpg', 'IPS LCD, 1B colors, 144Hz, HDR10, Dolby Vision, 550 nits\r\n\r\nâ–ªï¸11.0 inches, 350.9 cm2 1800 x 2880 pixels\r\n\r\nâ–ªï¸Android 13, MIUI 14\r\n\r\nâ–ªï¸GPU Adreno 650\r\n\r\nâ–ªï¸128GB 6GB RAM UFS 3.1\r\n\r\nâ–ªï¸13 MP, f/2.2, PDAF\r\n\r\nâ–ªï¸4K@30fps, 1080p@30/60fps\r\n', 'BrandXiaomiSKU117252263_MM-1037403762Body TypePlasticNumber Of Cameras2Pre-OwnedNoNotchted DisplayNo', 'Black/Blue/Gold'),
(6, 'Xiaomi Civi 2 5G', 'MI', 'Smart phone', '929,000', 'xiaomi-civi2.jpg', 'Xiaomi Civi 2 5G -Ram 12GB-Rom 256GB-Battery 4500mAn-Main Camera 50MP-Fast Charging 67W-Fingerprint', 'BrandXiaomiSKU117168956_MM-1037227797Body TypeGlassNumber Of Cameras3Pre-OwnedNoNotchted DisplayNoFa', 'Black/Blue/Silver'),
(7, 'Xiaomi black shark 5pro', 'MI', 'Smart phone', '1,500,000', 'shark5pro.jpg', 'Xiaomi Black Shark is a gaming phone that comes with 6.67-inch OLED display with 144Hz refresh rate and Qualcomm Snapdragon 8 Gen 1 processor. Specs also include 4650mAh battery with 120W charging speed, Triple camera setup on the back with 108MP main sen', 'BrandXiaomiSKU117197348_MM-1037315208Body TypeMetalNumber Of Cameras3Pre-OwnedNot SpecifiedNotchted ', 'Black / White'),
(8, 'Xiaomi Poco C40 (3/32GB)', 'MI', 'Smart phone', '269,000', 'Xiaomi_poco c40.jpg', 'ð—ªð—˜ð—Ÿð—–ð—¢ð— ð—˜ ð—™ð—¿ð—¼ð—º UOK\r\nð—§ð—µð—¶ð˜€ ð—£ð—¿ð—¼ð—±ð˜‚ð—°ð˜ ð—¶ð˜€ Thai ð—¢ð—³ð—³ð—¶ð—°ð—¶ð—®ð—¹ ðŸ­ ð—¬ð—²ð—®ð—¿ ð—ªð—®ð—¿ð—¿ð—®ð—»ð˜ð˜†\r\nðŸ­ðŸ¬ðŸ¬% ð—•ð—¿ð—®ð—»ð—± ð—¡ð—²ð˜„ ð—£ð—', 'randXiaomiSKU113460586_MM-1036338097Body TypePlasticNumber Of Cameras2Pre-OwnedNoNotchted DisplayYes', 'Black/Green'),
(9, 'Xiaomi Mibro T1', 'MI', 'Smart Watch', '70,000', 'xiaomi mibro t1.jpg', '1.6inch AMOLED HD display.\r\nâ€¢ Support Bluetooth Calling.\r\nâ€¢ Support dynamic heart rate & blood oxygen health management.\r\nâ€¢ Support 20 workout modes\r\nâ€¢ Support digital crown.\r\nâ€¢ 7-days calling endurance.\r\nâ€¢ 2ATM waterproof.\r\nâ€¢ T1 Smartwatch ', 'BrandXiaomiSKU117060961_MM-1037200561Display TypeAmoledGenerationNot SpecifiedMovementSmart', 'Black'),
(10, 'Mi Bro A1', 'MI', 'Smart Watch', '75,000', 'mibro-a1.jpg', 'Xiaomi Mibro A1 Smartwatch Specs\r\nBluetooth 5.0.\r\n1.28 in Touch Display.\r\nWater Resistant, 50 m, IP68.\r\nHeart Rate Monitor.\r\nSpO2 (Blood Oxygen) Monitor.\r\nPedometer, Sleep Monitor, Calorie Count, Step Count.\r\n10 days Battery.\r\nAlarm Clock, Stopwatch, Remi', 'BrandXiaomiSKU117060858_MM-1037201316Display TypeLEDGeneration1stMovementSmart Whatâ€™s in the box	W', 'Black'),
(11, 'Xiaomi Mibro GS(Global Version)', 'MI', 'Smart Watch', '159,000', 'mibrogs_.jpg', 'Product name:Mibro Watch GS\r\nâ—Product model:XPAW008\r\nâ—Connection:BLE5.1\r\nâ—Body material:Metal\r\nâ—Strap material:Liquid silica gel\r\nâ—Strap size:Width 22mm, expanded length 248mm\r\nâ—Battery capacity:460mAh\r\nâ—Charging method:Magnetic thimble char', 'BrandXiaomiSKU115212028_MM-1036676204Display TypeAmoledGenerationNot SpecifiedMovementSmart Whatâ€™s', 'Black'),
(12, 'Xiaomi Smart Band 7 Pro', 'MI', 'Smart Watch', ' 221,000', 'xiaomiband7pro.jpg', 'Product model: Xiaomi Mi Band 7 Pro\r\nBluetooth version: BT5.2\r\nScreen size: 1.64 inches\r\nScreen resolution: 456*280 (AMOLED color screen)\r\nBattery capacity: 235mAh\r\nSupport system: Android 6.0 or iOS 10.0 and above\r\nWristband material: TPU (applicable wri', 'BrandXiaomiSKU115075644_MM-1036638004Display TypeNot SpecifiedcolorBlack/ WhiteGenerationNot Specifi', 'White/Black'),
(13, 'Galaxy S22 Ultra 8/128', 'MI', 'Smart phone', '3,445,000', 'samsung-galaxy-s22-ultra-5g-3.jpg', 'Front Camera-40MP (F2.2)\r\nBattery - 5000mAh\r\nProcessor- Snapdragon 895 (4nm)\r\nSecurity- Ultrasonic Fingerprint, Secure Processor\r\nSpeaker-Stereo Speakers (sound by AKG)\r\nRAM/ Memory-8/128 GB\r\nRear Camera-108MP F1.8 (Wide), Super clear lens, 12MP F2.2 (Ult', 'SamsungSKU117214342_MM-1037343355Body TypeMetalNumber Of Cameras5Pre-OwnedNot SpecifiedNotchted Disp', 'Black/Burgundy'),
(14, 'Samsung Galaxy A04s (4/64GB)', 'SAMSUNG', 'Smart phone', ' 399,000', 'a04s_.jpg', 'ð—ªð—˜ð—Ÿð—–ð—¢ð— ð—˜ ð—™ð—¿ð—¼ð—º UOK\r\nð—§ð—µð—¶ð˜€ ð—£ð—¿ð—¼ð—±ð˜‚ð—°ð˜ ð—¶ð˜€ ð—¢ð—³ð—³ð—¶ð—°ð—¶ð—®ð—¹ ðŸ­ ð—¬ð—²ð—®ð—¿ ð—ªð—®ð—¿ð—¿ð—®ð—»ð˜ð˜†\r\nðŸ­ðŸ¬ðŸ¬% ð—•ð—¿ð—®ð—»ð—± ð—¡ð—²ð˜„ ð—£ð—®ð—°', 'BrandSamsungSKU113546084_MM-1036359009Body TypePlasticNumber Of Cameras4Pre-OwnedNoNotchted DisplayN', 'Black/Green'),
(15, 'Galaxy Z FIip 4 8GB/ 256GB', 'SAMSUNG', 'Smart phone', '3,639,000', 'Samsung-Galaxy-Z-Flip-4-500x500__94500_zoom.jpg', 'Snapdragon 8+Gen1 (4nm)\r\n8GB/ 256GB\r\n12MP+12MP e Front IOMP\r\n6.7" AMOLED\r\nBattery Li-Po 3700 mAh', 'BrandSamsungSKU117170490_MM-1037256192Body TypeGlassNumber Of Cameras3Pre-OwnedNot SpecifiedNotchted', 'Pink Gold/Graphite/Bora Purple/Blue'),
(16, 'Samsung Galaxy S21 (5G)', 'SAMSUNG', 'Smart phone', '1,030,000', 's21.jpg', 'Made by Korea\r\nOriginal Second Phone\r\nRam_8/256GB\r\nBattery_4000mah\r\nScreen size_6.2"\r\nDisplay_Dynamic AMOLED 2x,120Hz\r\nAlways on display + under display fingerprint\r\nAndroid 13 version\r\nStereo Speaker', 'BrandSamsungSKU117259105_MM-1037403411Body TypeNot SpecifiedNumber Of CamerasNot SpecifiedPre-OwnedN', 'Purple/Black/White'),
(17, 'Samsung Jump', 'SAMSUNG', 'Smart phone', '540,000', 'Samsung-Galaxy-Jump.jpg', 'Korea Original Second Phone\r\nRam 4/128\r\nCamera -48MP Quad Camera\r\nDimensity 720 5G CPU (7nm)\r\nBattery -5000mAh\r\nCharger -Type C', 'BrandSamsungSKU117254086_MM-1037408335Body TypeNot SpecifiedNumber Of CamerasNot SpecifiedPre-OwnedN', 'Black/White/Red'),
(18, 'Galaxy ZFold 4 12GB/ 256GB', 'SAMSUNG', 'Smart phone', '5,859,000', 'z4fold_.jpg', 'Snapdragon 8+Gen1\r\n12GB/ 256GB\r\n50MP+10MP+12MP\r\nFront 4MP+10MP\r\n7.6" AMOLED\r\nBattery Li-Po 4400 mAh', 'SamsungSKU117162971_MM-1037263702Body TypeNot SpecifiedNumber Of Cameras4Pre-OwnedNot SpecifiedNotch', 'Phantom Black/Graygreen/Beige'),
(19, 'Samsung Galaxy A90 (5G)', 'SAMSUNG', 'Smart phone', '500,000', 'a90.jpg', 'Ram -6 / 128 GB\r\nScreen Size -6.7"\r\nSuper Amoled\r\nSnapdragon 855\r\nBattery-4500mAh', 'BrandSamsungSKU117252184_MM-1037402440Body TypeNot SpecifiedNumber Of CamerasNot SpecifiedPre-OwnedN', 'Black/Pearl White'),
(20, 'Dell-Inspiron 14 5435 (R7-16GB-512GB-Win11) Silver-KMD', 'DELL', 'Laptop', '3,164,000', 'dell.jpg', 'IN54353Y85C001OGDDD\r\nAMD Ryzen(TM) 7 7730U 8-core/16-thread Processor with Radeon(TM) Graphics\r\n16GB 4266MHz LPDDR4x Memory Onboard\r\n512GB M.2 PCIe NVMe Solid State DriveUpdate M.2 PCIE 4x4 2280 Or 2230 Max 1TB\r\nOS -Windows 11 Home, Single Language Englis', 'BrandDellSKU117222512_MM-1037355980ProcessorAMDWarranty Policy ENParts &Services Warranty -2Years , ', 'Black/Silver'),
(21, 'Dell Inspiron 3511 (i5) 11th Gen', 'DELL', 'Laptop', '2,542,500', 'dell 355.jpg', ' 11th Gen Intel(R)Core (TM) i5-1135G7 Processor (8MB Cache, up to 4.2GHz)\r\n- 8GB, DDR4, 3200MHz (1x8GB)up to 16GB 1 Slot Free\r\n- 512GB PCIe SSD,up to 2TB,HDD Slot Free\r\n- Window 11 Home\r\n- 15.6"/FULL HD(1920X1080) (60Hz Anti-glare Panel)\r\n- No Drive\r\n- NV', 'BrandDellSKU112779749_MM-1036264210ProcessorIntelProcessor TypeIntel Core i5,Intel Core i5ModelDell ', 'Black'),
(22, 'DELL-Inspiron 3530 (i7-1355U-8GB-512GB SSD-Win 11 Home-Microsoft Office Home & Student 2021-1yr DP5) Cabon Black-KMD', 'DELL', 'Laptop', '2,953,000', 'dell 3530.jpg', 'IN35308JMPY001OGDDD\r\nIntelÂ® Core i7-1355U Processor (12MB Cache, up to 5.00 GHz)\r\n8GB, 1x8GB, DDR4, 3200 MHz2 Slot Max 16 GB\r\n512GB M.2 PCIe 2230 4x4 NVMe Solid State DriveUp to PCIE 2280 4x4 Max 2TB\r\nOS -Windows 11 Home, Single Language English\r\n15.6 in', 'BrandDellSKU117222368_MM-1037354554ProcessorIntel Core i7 Whatâ€™s in the box	Dell Note Book ,Dell E', 'Black'),
(23, 'Dell Inspiron 5420(I5-1235U-8GB-512GB SSD-Win 11 Home-IntelÂ® UHD Graphics-FP-Microsoft Office Home & Student 2021_Essential Backpack)_KMD', 'DELL', 'Laptop', '2,607,000', 'dell 5420_.jpg', 'Inspiron 14 5420 (i5)\r\nODINN514ADL23011004\r\nIntel(R) Core(TM) i5-1235U (12MB Cache, up to 4.4 GHz, 10 core\r\n8GB, 1x8GB, DDR4, 3200MHz,2 Slots 32GB Max\r\n512GB M.2 PCIe NVMe Solid State Drive,1 Slot Only\r\nWindows 11 Home, Single Language Englis\r\n14.0-inch 1', 'BrandDellSKU114761095_MM-1036566118ProcessorIntel Core i5', 'Black'),
(26, 'Dell Alienware m15 R6-15.6" IntelÂ®Core i7 11800H-16GB DDR4-512GB-Win 11-NVIDIA(R) GeForce-Dark Side of the Moon', 'DELL', 'Laptop', '6,952,000', 'dell-alienware-m15-r6-jpg.jpg', 'ARKTGLH22011500\r\nAlienware m15 R6 (i7)\r\nIntelÂ®Core i7 11800H (8-Core, 24MB L3 Cache, up to 4.6GHz with Turbo Boost\r\n16GB, 8GBx2, DDR4, 3200MHz\r\n512GB M.2 PCIe NVMe SSD\r\nWindows 11 Home, Single Language English\r\n15.6" FHD (1920 x 1080) 165Hz 3ms with Comf', 'BrandDellSKU110490125_MM-1035734116ProcessorIntel Core i7 Whatâ€™s in the box	Notebook, Alienware 61', 'Black'),
(27, 'Asus VivoBook 15 X515MA-EJ787W (Celeron)', 'ASUS', 'Laptop', '999,000', 'asus.jpg', 'Processor: Intel Celeron N4020 Processor 1.1GHz (4MB Cache, up to 2.8 GHz)\r\nRAM: 4GB DDR4 2666 MHz Memory\r\nStorage Size: 256GB\r\nGraphics: Intel UHD Graphics\r\nDrive: None\r\nScreen Size: 15.6â€³ FHD (60Hz)\r\nWireless: 802.11ac (1Ã—1), Bluetooth V 4.1\r\nOperati', 'BrandASUSSKU112521217_MM-1036235019ProcessorIntel Celeron Whatâ€™s in the box	Laptop', 'silver'),
(28, 'ASUS Vivobook 16_X1605VA-MB255W (i9-13900H-16GB-512GB-Win 11)TRANSPARENT SILVER-KMD', 'ASUS', 'Laptop', '2,787,000', 'vivo 16.jpg', 'X1605VA-MB255W\r\nIntelÂ® Coreâ„¢ i9-13900H Processor 2.6 GHz (24MB Cache, up to 5.4 GHz, 14 cores, 20 Threads)\r\n8GB DDR4 on board8GB DDR4 SO-DIMMExpansion Slot(includes used) 1x DDR4 SO-DIMM slotTotal System Memory (16 GB)\r\n512GB M.2 NVMeâ„¢ PCIeÂ® 3.0 SSD', 'BrandASUSSKU117222065_MM-1037332994ProcessorIntelWarranty Policy EN2 Years Battery & Adapter_1 Year ', 'Silver Moon'),
(29, 'ASUS Zenbook S 13 OLED_UX5304VA-NQ111W(I7-1355U- 16GB -512GB-Win 11)BASALT GREY-KMD', 'ASUS', 'Laptop', '4,572,000', 'zenbook_.jpg', 'UX5304VA-NQ111W\r\nIntelÂ® Coreâ„¢ i7-1355U Processor 1.7 GHz (12MB Cache, up to 5.0 GHz, 10 cores, 12 Threads)\r\n16GB LPDDR5 on board\r\n512GB M.2 NVMeâ„¢ PCIeÂ® 4.0 Performance SSD\r\nOS-Windows 11 Home 64 bit\r\n13.3-inch,2.8K (2880 x 1800) OLED 16:10 aspect ra', 'ASUSSKU117252581_MM-1037417646ProcessorIntel Core i7Warranty Policy ENParts &Services Warranty 2Year', 'Black'),
(30, 'ASUS TUF Gaming F15 (I7-12th Gen) Mecha Gray - FX507ZC4-HN046W', 'ASUS', 'Laptop', '3,524,000 ', 'tuf.jpg', 'CPU: 12th Gen IntelÂ® Coreâ„¢ i7-12700H Processor 2.3 GHz (24M Cache, up to 4.7 GHz, 14 cores: 6 P-cores and 8 E-cores)\r\nDisplay Size: 15.6" FHD 1920x1080 16:9 *144Hz* 720P HD camera\r\nMemory/Expansion Slot: 8GB DDR4-3200 SO-DIMM + 1 slot DDR4 free( total ', 'ASUSSKU117255415_MM-1037418029ProcessorIntel Core i7 Whatâ€™s in the box	1 x Laptop, 1 x Charger, 1 ', 'Gray'),
(31, 'ASUS-ROG Strix G17_G713PVÂ·LL075W (R9-7845HX-16GB-1TB SSD- RTX 4060 8GB- Win 11)', 'ASUS', 'Laptop', '6,178,000', 'strix.jpg', 'G713PV-LL075W\r\nAMD Ryzenâ„¢ 9 7845HX Mobile Processor (12-core/14-thread, 64MB L3 cache, up to 5.2 GHz max boost)\r\n8GB DDR5-4800 SO-DIMM *2 1 slot DDR5 free ( total up to 32GB)\r\n1TB PCIeÂ® 4.0 NV Meâ„¢ M.2 SSD 1 x M2 slot free\r\n17.3-inch WQHD (2560 x 1440', 'BrandASUSSKU117203011_MM-1037312021ProcessorAMDWarranty Policy ENParts & Services 2 Years Battery & ', 'Eclipse Gray'),
(32, 'Acer Aspire 5G ( A515-57-33V4 (i3) 12th Gen, 8GB 1215U Processor ) - Glacier Blue Color Laptop , Computer ( 15.6" FHD )', 'acer', 'Laptop', '1,796,500 ', '4zu3_Acer_Aspire_5.jpg', 'CPU and Chipset : IntelÂ® Core TM i3-1215U Processor,( 10MB Cache, 1.2GHz up to 4.4Hz )\r\nGraphic : NVIDIAÂ® GeForceÂ® MX550 with 2GB VRAM\r\nMemory : 4 GB DDR4 3200MHz Memory ( One Slot Free up to 16GB )\r\nStorage : 256GB PCle NV Me SSD ( One slot free PCIe ', 'BrandAcerSKU117205118_MM-1037311292ProcessorIntel Core i3 Whatâ€™s in the box	Laptop + Laptop Backpa', 'Navy Blue/Black/Blue'),
(33, 'Acer Extensa 15 (Pentium)', 'acer', 'Laptop', '1,100,000', 'ex.jpg', 'IntelÂ® PentiumÂ® Silver N6000 Processor ( 4MB Cache, 1.10 GHz up to 3.30GHz )\r\n: Intel Â® UHD Graphics\r\n: 4 GB DDR4 Memory ( One Slot Free )\r\n: 256 GB PCIE SSD\r\n: 15.6â€ FHD Acer ComfyViewTM\r\n: USB 2.0 ( Dual ), 3.0 , HDMI, GBLAN\r\n: WLAN 802.11ac + Blue', 'BrandAcerSKU112167106_MM-1036116689ProcessorIntel PentiumDisplay Size15.6Processor TypeIntel Pentium', 'Black'),
(34, 'ACER Swift3 ( SF314-512-54CV (i5) 12th Gen ) ', 'acer', 'Laptop', '2,650,500', 'swift_.jpg', 'CPU and Chipset : IntelÂ® CoreTM i5-1240P Processor ( up to 4.40 GHz, 12MB smart cache)\r\nGraphic : Intel Iris Xe Graphics\r\nMemory : 8GB LPDDR4 , 4267 MT/s Memory ( No slot free )\r\nStorage : 512GB PCle NVMe SSD ( Can be upgraded 1TB ) ( No slot free )\r\nDis', 'BrandAcerSKU115863936_MM-1036881148Display Size14Processor TypeIntel,Intel Core i5ram_memory8GBTouch', 'Black'),
(37, 'Remax Earphone (RM-501)', 'Remax', 'Ear Buds', '10,875', 'remax.jpg', 'Brand: REMAX\r\nName: RM-501 Earphone\r\nModel: RM-501\r\nFunction: Music Player\r\nFeatures: HD Microphone / Compatibility\r\nWeight : 0.18kg\r\nFrequency range: 20-20000HZ\r\nLevel of sensitivity: 96dB/1Khz\r\nImpedamce: 30Î©\r\nMax Power: 100mW\r\nPlug: 3.5mm\r\nCord Length', 'RemaxSKU587052_MM-1023909008Cable Length1.0m - 1.4m', 'Black/Blue/Pink/White'),
(38, 'Remax RM-712 Gaming Wired Earphone', 'Remax', 'Ear Buds', '33,500', 'regame.jpg', 'Model :RM-712\r\nWearing Type:In-ear\r\nConnectivity:Wired\r\nEarphone Jack :3.5mm\r\nFrequency Response :20-20000Hz\r\nOutput Sensitivity :98dB+3dB\r\nModel :RM-712\r\nWearing Type:In-ear\r\nConnectivity:Wired', 'BrandRemaxSKU117253050_MM-1037413085Cable Length1.0m - 1.4m', 'Red'),
(39, 'REMAX..-COZYBUDS 6C AURORA SERIES CLEARTRUE WIRLESS EARBUDS', 'Remax', 'Ear Buds', '24,650', 'cozy.jpg', 'Model--CozyBuds 6C/Colour---Black/Orange/White/Place---Display Stand to hook / Warranty---6months\r\nWireless Version---V53/Transmission distance---10m/Driver Unit---.13mm\r\nFrequency response ---20H2-20KHz /mpedance---322 /Rated power---2mW/Net Weight---32g', 'randRemaxSKU115896419_MM-1036878589Compatible DevicesNot Specified', 'White/Black/Orange'),
(40, 'RB - X5 Outdoor Bluetooth Speaker,Speaker,Bluetooth Speaker,Wireless Speaker,Desktop Speaker, Portable Speaker,Mini Bluetooth Speaker,wireless', 'Remax', 'Bluetooth Speaker', '405,000 ', 'rbx5.jpg', 'Model : RB-X5\r\nColour : Green / Black\r\nMicrophone distance meters :10m\r\nFrequency : 20Hz ~20kHz(+2db)\r\nRate Power : 50W\r\nMusic Playtime : 1 Day if light is off, 12 hours if light is on\r\nCharging Time : 8 to 10 hours\r\nCharging Voltage : DC15V\r\nBattery Capa', 'BrandRemaxSKU652279_MM-1023908021 Whatâ€™s in the box	RB - X5 Outdoor Bluetooth Speaker', 'Black');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `reg_id` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `phone` int(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` int(30) NOT NULL,
  `confirmpassword` int(30) NOT NULL,
  PRIMARY KEY (`reg_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`reg_id`, `username`, `phone`, `email`, `address`, `password`, `confirmpassword`) VALUES
(1, 'FU FU', 2147483647, 'fu@gmail.com', 'Yangon', 12345, 12345),
(2, 'Zay Yar Lin Htet', 945009861, 'zay@gmail.com', 'Yangon', 12345, 12345),
(3, 'Dummy1', 2147483647, 'dum@gamil.com', 'Yangon', 12345, 12345),
(4, 'Dummy2', 98767890, 'dum2@gmail.com', 'Yangon', 12345, 12345),
(5, 'Dummy3', 978657677, 'dum3@gmail.com', 'Yangon', 123456, 123456);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `pass`) VALUES
(1, 'admin', '968181');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
