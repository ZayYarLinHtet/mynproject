$(document).ready(function() {  
  $('#cartModal').modal('show');
});