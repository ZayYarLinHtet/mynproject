<?php 
$host = "localhost";
$user = "root";
$password = "";
$database = "eledb";

// Create a connection
$con = mysqli_connect($host, $user, $password, $database);

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
?>