<!DOCTYPE html>
<html lang="en">

<head>
    <title>Electro Shop - Product Detail Page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="assets/img/apple-icon.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    

    <!-- Load fonts style after rendering the layout styles -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">

    <!-- Slick -->
    <link rel="stylesheet" type="text/css" href="assets/css/slick.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/slick-theme.css">
<!--
    
TemplateMo 559 Zay Shop

https://templatemo.com/tm-559-zay-shop

-->
<?php
error_reporting(1);
  include("admin/function.php");
  ?>
</head>

<body>
    <!-- Start Top Nav -->
    <nav class="navbar navbar-expand-lg bg-dark navbar-light d-none d-lg-block" id="templatemo_nav_top">
        <div class="container text-light">
            <div class="w-100 d-flex justify-content-between">
                <div>
                    <i class="fa fa-envelope mx-2"></i>
                    <a class="navbar-sm-brand text-light text-decoration-none" href="mailto:zylhucsmb@gmail.com">zylhucsmb@gmail.com</a>
                    <i class="fa fa-phone mx-2"></i>
                    <a class="navbar-sm-brand text-light text-decoration-none" href="tel:09-961818038">09-961818038</a>
                </div>
            </div>
        </div>
    </nav>
    <!-- Close Top Nav -->


    <!-- Header -->
    <nav class="navbar navbar-expand-lg navbar-light shadow">
        <div class="container d-flex justify-content-between align-items-center">

            <a class="navbar-brand text-success logo h1 align-self-center" href="index.php">
                Electro Shop
            </a>

            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#templatemo_main_nav" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="align-self-center collapse navbar-collapse flex-fill  d-lg-flex justify-content-lg-between" id="templatemo_main_nav">
                <div class="flex-fill">
                    <ul class="nav navbar-nav d-flex justify-content-between mx-lg-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="shop.php">Shop</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact</a>
                        </li>
                    </ul>
                </div>
                </div>
            </div>
        </div>
    </nav>
    <!-- Modal -->
    <div class="modal fade bg-white" id="templatemo_search" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="w-100 pt-1 mb-5 text-right">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="" method="get" class="modal-content modal-body border-0 p-0">
                <div class="input-group mb-2">
                    <input type="text" class="form-control" id="inputModalSearch" name="q" placeholder="Search ...">
                    <button type="submit" class="input-group-text bg-success text-light">
                        <i class="fa fa-fw fa-search text-white"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>

       <?php
    if (isset($_GET['pro_id'])) {
    $product_id = $_GET['pro_id'];
    $query = "SELECT * FROM product WHERE p_id='$product_id'";
    $result = mysqli_query($con, $query); // Fix: Use $query instead of $result in the mysqli_query() function
    if (!$result) {
        die("Error executing the query: " . mysqli_error($con));
    }
    
                while ($row = mysqli_fetch_assoc($result)) {
            
					echo " 
                    <section class='bg-light'>
    <div class='container pb-5'>    
        <div class='row'>
            <div class='col-lg-5 mt-5'>
                <div class='card mb-3'>
                    <img class='card-img img-fluid' src='admin/image/{$row['p_img']}' alt='Card image cap' id='product-detail'>
                </div>
            </div>
            <div class='col-lg-7 mt-5'>
                <div class='card'>
                    <div class='card-body'>
                        <h1 class='h2'>{$row['p_name']}</h1>
                        <p class='h3 py-2'>{$row['p_price']} ks</p>
                        <ul class='list-inline'>
                            <li class='list-inline-item'>
                                <h6>Category:</h6>
                            </li>
                            <li class='list-inline-item'>
                                <p class='text-muted'><strong>{$row['p_category']}</strong></p>
                            </li>
                        </ul>
                        <ul class='list-inline'>
                            <li class='list-inline-item'>
                                <h6>Brand:</h6>
                            </li>
                            <li class='list-inline-item'>
                                <p class='text-muted'><strong>{$row['p_brand']}</strong></p>
                            </li>
                        </ul>
                        <h6>Description:</h6>
                        <p>{$row['p_desc']}</p>
                        <ul class='list-inline'>
                            <li class='list-inline-item'>
                                <h6>Available Color :</h6>
                            </li>
                            <li class='list-inline-item'>
                                <p class='text-muted'><strong>{$row['p_color']}</strong></p>
                            </li>
                        </ul>
                        <h6>Specification:</h6>
                        <ul class='list-unstyled pb-3'>
                            <li>{$row['p_spec']}</li>
                        </ul>
                        <form action='#' method='GET'>
                            <input type='hidden' name='product-title' value='Activewear'>
                            <div class='row pb-3'>
                                <div class='col d-grid'>
                                    <a button type='submit' class='btn btn-success btn-lg' name='submit' value='buy' href='login.php?buy_pro={$row['p_id']}'>Buy</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            </div>
            </div>
            </section>
					";
                }
            }
			?>    
    <!-- Close Content -->

    <!-- Start Article -->
    <section class="py-5">
        <div class="container">
            <div class="row text-left p-2 pb-3">
                <h4>Related Products</h4>
            </div>
             
            <!--Start Carousel Wrapper-->
            <div id="carousel-related-product">
            <?php  getP();?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Article -->


    <!-- Start Footer -->
    <footer class="bg-dark" id="tempaltemo_footer">
        <div class="container">
            <div class="row">

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-success border-bottom pb-3 border-light logo">Electro Shop</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li>
                            <i class="fa fa-phone fa-fw"></i>
                            <a class="text-decoration-none" href="tel:09-961818038">09-961818038</a>
                        </li>
                        <li>
                            <i class="fa fa-envelope fa-fw"></i>
                            <a class="text-decoration-none" href="mailto:zylhucsmb@gmail.com">zylhucsmb@gmail.com</a>
                        </li>
                    </ul>
                </div>

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Products</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="#">Laptop</a></li>
                        <li><a class="text-decoration-none" href="#">Smart Phone</a></li>
                        <li><a class="text-decoration-none" href="#">Smart Watch</a></li>
                        <li><a class="text-decoration-none" href="#">Ear Buds</a></li>
                        <li><a class="text-decoration-none" href="#">Bluetooth Speaker</a></li>
                        <li><a class="text-decoration-none" href="#">Phone and Laptop Accessories</a></li>
                        <li><a class="text-decoration-none" href="#">Covers</a></li>
                    </ul>
                </div>

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Further Info</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="index.html">Home</a></li>
                        <li><a class="text-decoration-none" href="about.html">About Us</a></li>
                        <li><a class="text-decoration-none" href="faq.html">FAQs</a></li>
                        <li><a class="text-decoration-none" href="contact.html">Contact</a></li>
                    </ul>
                </div>

            </div>
        </div>

        <div class="w-100 bg-black py-3">
            <div class="container">
                <div class="row pt-2">
                    <div class="col-12">
                        <p class="text-left text-light">
                            Copyright &copy; 2023 Page Myanmar Professional Web Training
                            | Designed by <a rel="sponsored" href="https://templatemo.com" target="_blank">Zay Yar Lin Htet</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </footer>
    <!-- End Footer -->

    <!-- Start Script -->
    <script src="assets/js/jquery-1.11.0.min.js"></script>
    <script src="assets/js/jquery-migrate-1.2.1.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/templatemo.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- End Script -->

    <!-- Start Slider Script -->
    <script src="assets/js/slick.min.js"></script>
    <script>
        $('#carousel-related-product').slick({
            infinite: true,
            arrows: false,
            slidesToShow: 4,
            slidesToScroll: 3,
            dots: true,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 3
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 3
                    }
                }
            ]
        });
    </script>
    <!-- End Slider Script -->

</body>

</html>