
<!DOCTYPE html>
<!-- Created By CodingNepal -->
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Electro Shop | Login</title>
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="code/bootstrap.min.css">
  <script src="code/jquery.min.js"></script>
  <script src="code/popper.min.js"></script>
  <script src="code/bootstrap.min.js"></script>
  <?php
	error_reporting(1);
	include("connection.php");
	
	$id = $_REQUEST['buy_pro'];
	if(isset($_REQUEST['login']))
	{
      $email = $_REQUEST['email'];
      $pass = $_REQUEST['pass'];
		$query = "SELECT email,password FROM register WHERE email='$email'";
		$result = mysqli_query($con,$query) or die("Save items query failed.");
      if($result){
         $arr=mysqli_fetch_array($result);
		if(($arr['email']==$email) && ($arr['password']==$pass))
		{
           
			echo "<script>location.href='buy.php?buy_pro=$id'</script>";
         
		}
		else
		{
			$er=" <div class='alert alert-danger alert-dismissible fade show'>
              <h6>Email or Password Incorrect</h6>
       </div>";
		}
	}
}
?>



   </head>
   <body>
      <div class="wrapper">
         <div class="title">
            Login 
         </div>
         <h4><?php echo $er;?></h4>
         <form method="post" action="#">
            <div class="field">
               <input type="text"  name="email" id="id"  required>
               <label>Email Address</label>
            </div>
            <div class="field">
               <input type="password" name="pass" id="pwd" required>
               <label>Password</label>
            </div>
            <div class="field">
               <input type="submit"  name="login" id="sub" value="Login">
            </div>
            <div class="signup-link">
               Not a member? <a href="regristration.php">Signup now</a>
            </div>
         </form>
      </div>
   </body>
</html>