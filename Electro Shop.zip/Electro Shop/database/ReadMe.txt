Database Name : eledb;
Admin username: admin;
       password:968181;

thank you for read this text.
