<?php


$con=mysqli_connect("localhost","root","","eledb");
function getBrands(){
    global $con;
    $get_brand = "SELECT * FROM brand";
    $run_brand = mysqli_query($con,$get_brand);
    while($row_brand = mysqli_fetch_array($run_brand))
		{
			$b_id = $row_brand['b_id'];
			$b_title = $row_brand['b_title'];
			echo "
            <ul class='list-unstyled templatemo-accordion'>
            <li class='pb-3'>
            <a class='collapsed d-flex justify-content-between h3 text-decoration-none' href='shop.php?brand=$b_title'>$b_title</a>
            </li>
        </ul>";
		}
}


function getCategory()
	{
		global $con;
		$get_category = "SELECT * FROM category";
		$run_category = mysqli_query($con, $get_category);
if (!$run_category) {
    die('Error executing the query: ' . mysqli_error($con));
}
 
		while($row_category = mysqli_fetch_array($run_category))
		{
			$c_id = $row_category['c_id'];
			$c_title = $row_category['c_title'];
			echo " <ul class='list-unstyled templatemo-accordion'>
            <li class='pb-3'>
                <a class='collapsed d-flex justify-content-between h3 text-decoration-none' href='shop.php?category=$c_title'>$c_title
                </a>
            </li>
        </ul>";
		}
	}

function getP()
	{
	  if(!isset($_GET['brand']))
	  {
		global $con;
		$get_pro = "SELECT * FROM product order by rand()";
		$run_pro = mysqli_query($con,$get_pro);
		while($row_pro = mysqli_fetch_array($run_pro))
		{ 
			$pro_id = $row_pro['p_id'];
            $pro_name = $row_pro['p_name'];
			$pro_price = $row_pro['p_price'];
			$pro_image = $row_pro['p_img'];
			echo " 
            <div class='col-md-4'>
            <div class='card mb-4 product-wap rounded-0'>
                <div class='card rounded-0'>
                    <img class='card-img rounded-0 img-fluid' src='admin/image/$pro_image' width='400px' height='400px'>
                    <div class='card-img-overlay rounded-0 product-overlay d-flex align-items-center justify-content-center'>
                        <ul class='list-unstyled'>
                            <li><a class='btn btn-success text-white mt-2' href='shop-single.php?pro_id=$pro_id'><i class='far fa-eye'></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class='card-body'>
                    <a href='shop-single.php' class='h3 text-decoration-none'>$pro_name</a>
                    <ul class='w-100 list-unstyled d-flex justify-content-between mb-0'>
                        <li class='pt-2'>
                            <span class='product-color-dot color-dot-red float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-blue float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-black float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-light float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-green float-left rounded-circle ml-1'></span>
                        </li>
                    </ul>
                    <p class='text-center mb-0'>$pro_price ks</p>
                </div>
            </div>
        </div>
			
			
			";
			
		}
	  }
	}

   /* function getBrandPro()
	{
	  if(isset($_GET['brand']))
	  {
		global $con;
		$brand_title = $_GET['brand'];
		$get_brand_pro = "SELECT * FROM product WHERE p_brand='$brand_title'";
		$run_brand_pro = mysqli_query($con,$get_brand_pro);
		while($row_brand_pro = mysqli_fetch_array($run_brand_pro))
		{ 
			$pro_id = $row_brand_pro['p_id'];
            $pro_name = $row_brand_pro['p_name'];
			$pro_price = $row_brand_pro['p_price'];
			$pro_image = $row_brand_pro['p_img'];
			echo " 
            <div class='col-md-4'>
            <div class='card mb-4 product-wap rounded-0'>
                <div class='card rounded-0'>
                    <img class='card-img rounded-0 img-fluid' src='admin/image/$pro_image' width='400px' height='400px'>
                    <div class='card-img-overlay rounded-0 product-overlay d-flex align-items-center justify-content-center'>
                        <ul class='list-unstyled'>
                            <li><a class='btn btn-success text-white mt-2' href='shop-single.php?pro_id=$pro_id'><i class='far fa-eye'></i></a></li>
                            <li><a class='btn btn-success text-white mt-2' href='shop-single.php'><i class='fas fa-cart-plus'></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class='card-body'>
                    <a href='shop-single.php' class='h3 text-decoration-none'>$pro_name</a>
                    <ul class='w-100 list-unstyled d-flex justify-content-between mb-0'>
                        <li class='pt-2'>
                            <span class='product-color-dot color-dot-red float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-blue float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-black float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-light float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-green float-left rounded-circle ml-1'></span>
                        </li>
                    </ul>
                    <p class='text-center mb-0'>$pro_price</p>
                </div>
            </div>
        </div>
			
			";
			
		}
	  }
	}  */

    function getProduct($pageNumber, $itemsPerPage)
{
    global $con;

    // Calculate the offset based on the current page and items per page
    $offset = ($pageNumber - 1) * $itemsPerPage;

    // Modify the SQL query to include the LIMIT clause for pagination
    $get_pro = "SELECT * FROM product ORDER BY rand() LIMIT $offset, $itemsPerPage";

    // Execute the query and retrieve the product data
    $run_pro = mysqli_query($con, $get_pro);

    while ($row_pro = mysqli_fetch_array($run_pro)) {
        // ... Your existing code to display the products ...
        $pro_id = $row_pro['p_id'];
            $pro_name = $row_pro['p_name'];
			$pro_price = $row_pro['p_price'];
			$pro_image = $row_pro['p_img'];
			echo " 
            <div class='col-md-4'>
            <div class='card mb-4 product-wap rounded-0'>
                <div class='card rounded-0'>
                    <img class='card-img rounded-0 img-fluid' src='admin/image/$pro_image' width='400px' height='400px'>
                    <div class='card-img-overlay rounded-0 product-overlay d-flex align-items-center justify-content-center'>
                        <ul class='list-unstyled'>
                            <li><a class='btn btn-success text-white mt-2' href='shop-single.php?pro_id=$pro_id'><i class='far fa-eye'></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class='card-body'>
                    <a href='shop-single.php' class='h3 text-decoration-none'>$pro_name</a>
                    <ul class='w-100 list-unstyled d-flex justify-content-between mb-0'>
                        <li class='pt-2'>
                            <span class='product-color-dot color-dot-red float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-blue float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-black float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-light float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-green float-left rounded-circle ml-1'></span>
                        </li>
                    </ul>
                    <p class='text-center mb-0'>$pro_price ks</p>
                </div>
            </div>
        </div>
			
			
			";
    }
}

function getBrandPro($pageNumber, $itemsPerPage)
{
    global $con;

    // Calculate the offset based on the current page and items per page
    $offset = ($pageNumber - 1) * $itemsPerPage;

    // Get the brand title from the URL query parameter 'brand'
    if (isset($_GET['brand'])) {
        $brand_title = $_GET['brand'];

        // Modify the SQL query to include the LIMIT clause for pagination
        $get_brand_pro = "SELECT * FROM product WHERE p_brand='$brand_title' LIMIT $offset, $itemsPerPage";

        // Execute the query and retrieve the brand product data
        $run_brand_pro = mysqli_query($con, $get_brand_pro);

        while ($row_brand_pro = mysqli_fetch_array($run_brand_pro)) {
            // ... Your existing code to display the brand products ...

            $pro_id = $row_brand_pro['p_id'];
            $pro_name = $row_brand_pro['p_name'];
			$pro_price = $row_brand_pro['p_price'];
			$pro_image = $row_brand_pro['p_img'];
			echo " 
            <div class='col-md-4'>
            <div class='card mb-4 product-wap rounded-0'>
                <div class='card rounded-0'>
                    <img class='card-img rounded-0 img-fluid' src='admin/image/$pro_image' width='400px' height='400px'>
                    <div class='card-img-overlay rounded-0 product-overlay d-flex align-items-center justify-content-center'>
                        <ul class='list-unstyled'>
                            <li><a class='btn btn-success text-white mt-2' href='shop-single.php?pro_id=$pro_id'><i class='far fa-eye'></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class='card-body'>
                    <a href='shop-single.php' class='h3 text-decoration-none'>$pro_name</a>
                    <ul class='w-100 list-unstyled d-flex justify-content-between mb-0'>
                        <li class='pt-2'>
                            <span class='product-color-dot color-dot-red float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-blue float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-black float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-light float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-green float-left rounded-circle ml-1'></span>
                        </li>
                    </ul>
                    <p class='text-center mb-0'>$pro_price ks</p>
                </div>
            </div>
        </div>
			
			";
        }
    }
}


    function getCategoryPro()
	{
	  if(isset($_GET['category']))
	  {
		global $con;
		$c_name = $_GET['c_name'];
		$get_category_pro = "SELECT * FROM product WHERE p_category='$c_name'";
		$run_category_pro = mysqli_query($con,$get_category_pro);
		while($row_category_pro = mysqli_fetch_array($run_category_pro))
		{ 
			$pro_id = $row_category_pro['p_id'];
            $pro_name = $row_category_pro['p_name'];
			$pro_price = $row_category_pro['p_price'];
			$pro_image = $row_category_pro['p_img'];
            echo"
            <div class='col-md-4'>
            <div class='card mb-4 product-wap rounded-0'>
                <div class='card rounded-0'>
                    <img class='card-img rounded-0 img-fluid' src='admin/image/$pro_image' width='400px' height='400px'>
                    <div class='card-img-overlay rounded-0 product-overlay d-flex align-items-center justify-content-center'>
                        <ul class='list-unstyled'>
                            <li><a class='btn btn-success text-white mt-2' href='shop-single.php?pro_id=$pro_id'><i class='far fa-eye'></i></a></li>
                            <li><a class='btn btn-success text-white mt-2' href='shop-single.php'><i class='fas fa-cart-plus'></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class='card-body'>
                    <a href='shop-single.php' class='h3 text-decoration-none'>$pro_name</a>
                    <ul class='w-100 list-unstyled d-flex justify-content-between mb-0'>
                        <li class='pt-2'>
                            <span class='product-color-dot color-dot-red float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-blue float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-black float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-light float-left rounded-circle ml-1'></span>
                            <span class='product-color-dot color-dot-green float-left rounded-circle ml-1'></span>
                        </li>
                    </ul>
                    <p class='text-center mb-0'>$pro_price</p>
                </div>
            </div>
        </div>
			
            
            ";
        }
    }
    }

    

  

/*function getProduct($pageNumber, $itemsPerPage) {
    global $con;

    // Calculate the offset based on the current page and items per page
    $offset = ($pageNumber - 1) * $itemsPerPage;

    // Modify the SQL query to include the LIMIT clause for pagination
    $query = "SELECT * FROM product LIMIT $offset, $itemsPerPage";

    // Execute the query and retrieve the product data
    $result = mysqli_query($con, $query);
    if (!$result) {
        die("Error executing the query: " . mysqli_error($con));
    }

    // Display the products
    while ($row = mysqli_fetch_assoc($result)) {
        // ... Your code to generate HTML markup for displaying products ...
        echo "<div class='col-md-4'>
        <div class='card mb-4 product-wap rounded-0'>
            <div class='card rounded-0'>
                <img class='card-img rounded-0 img-fluid' src='admin/image/{$row['p_img']}' width='400px' height='400px'>
                <div class='card-img-overlay rounded-0 product-overlay d-flex align-items-center justify-content-center'>
                    <ul class='list-unstyled'>
                        <li><a class='btn btn-success text-white mt-2' href='shop-single.php?{$row['p_id']}={$row['p_id']}'><i class='far fa-eye'></i></a></li>
                        <li><a class='btn btn-success text-white mt-2' href='shop-single.php'><i class='fas fa-cart-plus'></i></a></li>
                    </ul>
                </div>
            </div>
            <div class='card-body'>
                <a href='shop-single.php' class='h3 text-decoration-none'>{$row['p_name']}</a>
                <ul class='w-100 list-unstyled d-flex justify-content-between mb-0'>
                    <li class='pt-2'>
                        <span class='product-color-dot color-dot-red float-left rounded-circle ml-1'></span>
                        <span class='product-color-dot color-dot-blue float-left rounded-circle ml-1'></span>
                        <span class='product-color-dot color-dot-black float-left rounded-circle ml-1'></span>
                        <span class='product-color-dot color-dot-light float-left rounded-circle ml-1'></span>
                        <span class='product-color-dot color-dot-green float-left rounded-circle ml-1'></span>
                    </li>
                </ul>
                <p class='text-center mb-0'>{$row['p_price']}</p>
            </div>
        </div>
    </div>
    ";
       
    }
}

function getBrandPro($pageNumber, $itemsPerPage) {
    global $con;

    // Calculate the offset based on the current page and items per page
    $offset = ($pageNumber - 1) * $itemsPerPage;

    // Modify the SQL query to include the LIMIT clause for pagination
    $query = "SELECT * FROM product LIMIT $offset, $itemsPerPage";

    // Execute the query and retrieve the brand product data
    $result = mysqli_query($con, $query);
    if (!$result) {
        die("Error executing the query: " . mysqli_error($con));
    }

    // Display the brand products
    while ($row = mysqli_fetch_assoc($result)) {
        // ... Your code to generate HTML markup for displaying brand products ...
       
        echo "<div class='col-md-4'>
        <div class='card mb-4 product-wap rounded-0'>
            <div class='card rounded-0'>
                <img class='card-img rounded-0 img-fluid' src='admin/image/{$row['p_img']}' width='400px' height='400px'>
                <div class='card-img-overlay rounded-0 product-overlay d-flex align-items-center justify-content-center'>
                    <ul class='list-unstyled'>
                        <li><a class='btn btn-success text-white mt-2' href='shop-single.php?{$row['p_id']}={$row['p_id']}'><i class='far fa-eye'></i></a></li>
                        <li><a class='btn btn-success text-white mt-2' href='shop-single.php'><i class='fas fa-cart-plus'></i></a></li>
                    </ul>
                </div>
            </div>
            <div class='card-body'>
                <a href='shop-single.php' class='h3 text-decoration-none'>{$row['p_name']}</a>
                <ul class='w-100 list-unstyled d-flex justify-content-between mb-0'>
                    <li class='pt-2'>
                        <span class='product-color-dot color-dot-red float-left rounded-circle ml-1'></span>
                        <span class='product-color-dot color-dot-blue float-left rounded-circle ml-1'></span>
                        <span class='product-color-dot color-dot-black float-left rounded-circle ml-1'></span>
                        <span class='product-color-dot color-dot-light float-left rounded-circle ml-1'></span>
                        <span class='product-color-dot color-dot-green float-left rounded-circle ml-1'></span>
                    </li>
                </ul>
                <p class='text-center mb-0'>{$row['p_price']}</p>
            </div>
        </div>
    </div>
    ";
    }
}*/


    
?>